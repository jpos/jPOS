package com.vsalaman.example.crypto;

/**
 * all parameter classes implement this.
 */
public interface CipherParameters
{
}
