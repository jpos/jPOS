package com.vsalaman.example;

import com.vsalaman.example.crypto.*;

/**
 * Generates an ISO9797-1/ANSI 9.19 MAC using SingleDES/TripleDES Final Block.
 *
 * NOTE:
 * The code used in supporting classes (com.vsalaman.example.crypto.*) come from
 * BouncyCastle's excellent crypto library, so if you have more crypto needs, this
 * file can be easily modified to just use their jar instead by replacing the imports.
 *
 * @author <a href='vsalaman@gmail.com'>Victor Salaman</a>
 */
public class RetailMACGenerator
{
    //---------------<< FIELDS >>---------------

    private byte[] mac;
    private byte[] buf;
    private int bufOff;
    private LastBlockDiffCBCBlockCipher cipher;
    private int macSize;

    //---------------<< CONSTRUCTORS >>---------------

    public RetailMACGenerator()
    {
        super();
        cipher = new LastBlockDiffCBCBlockCipher();
        macSize = 4;

        mac = new byte[cipher.getBlockSize()];
        buf = new byte[cipher.getBlockSize()];
        bufOff = 0;
    }

    //---------------<< GETTER / SETTER METHODS >>---------------

    public int getMacSize()
    {
        return macSize;
    }

    //---------------<< OTHER METHODS >>---------------

    public int doFinal(byte[] out,
                       int outOff)
    {
        cipher.processBlock(buf, 0, mac, 0, true);
        System.arraycopy(mac, 0, out, outOff, macSize);
        reset();
        return macSize;
    }

    public void init(byte[] key)
    {
        reset();
        byte[] desKey = new byte[8];
        System.arraycopy(key, 0, desKey, 0, 8);
        KeyParameter params1 = new KeyParameter(desKey);
        KeyParameter params2 = new KeyParameter(key);
        cipher.init(true, params1, params2);
    }

    /**
     * Reset the mac generator.
     */
    public void reset()
    {
        /*
           * clean the buffer.
           */
        for (int i = 0; i < buf.length; i++)
        {
            buf[i] = (byte) 0;
        }

        bufOff = 0;

        /*
           * reset the underlying cipher.
           */
        cipher.reset();
    }

    public void update(byte in)
    {
        if (bufOff == buf.length)
        {
            cipher.processBlock(buf, 0, mac, 0, false);
            bufOff = 0;
        }

        buf[bufOff++] = in;
    }

    public void update(byte[] in,
                       int inOff,
                       int len)
    {
        if (len < 0)
        {
            throw new IllegalArgumentException("Can't have a negative input length!");
        }

        int blockSize = cipher.getBlockSize();
        int gapLen = blockSize - bufOff;

        if (len > gapLen)
        {
            System.arraycopy(in, inOff, buf, bufOff, gapLen);

            cipher.processBlock(buf, 0, mac, 0, false);

            bufOff = 0;
            len -= gapLen;
            inOff += gapLen;

            while (len > blockSize)
            {
                cipher.processBlock(in, inOff, mac, 0, false);

                len -= blockSize;
                inOff += blockSize;
            }
        }

        System.arraycopy(in, inOff, buf, bufOff, len);

        bufOff += len;
    }

    //---------------<< INNER CLASSES >>---------------

    public class LastBlockDiffCBCBlockCipher
    {
        private BlockCipher desede = new DESedeEngine();
        private BlockCipher cipher = new DESEngine();
        private byte[] IV;
        private byte[] cbcV;
        private byte[] cbcNextV;
        private int blockSize;
        private boolean encrypting;

        public LastBlockDiffCBCBlockCipher()
        {
            super();
            blockSize = cipher.getBlockSize();

            IV = new byte[blockSize];
            cbcV = new byte[blockSize];
            cbcNextV = new byte[blockSize];
        }

        public void init(boolean encrypting,
                         CipherParameters params1, CipherParameters params2)
                throws IllegalArgumentException
        {
            this.encrypting = encrypting;

            if (params1 instanceof ParametersWithIV)
            {
                ParametersWithIV ivParam = (ParametersWithIV) params1;
                byte[] iv = ivParam.getIV();

                if (iv.length != blockSize)
                {
                    throw new IllegalArgumentException("initialisation vector must be the same length as block size");
                }

                System.arraycopy(iv, 0, IV, 0, iv.length);

                reset();

                cipher.init(encrypting, ivParam.getParameters());
            }
            else
            {
                reset();

                cipher.init(encrypting, params1);
            }

            if (params2 instanceof ParametersWithIV)
            {
                ParametersWithIV ivParam = (ParametersWithIV) params2;
                byte[] iv = ivParam.getIV();

                if (iv.length != blockSize)
                {
                    throw new IllegalArgumentException("initialisation vector must be the same length as block size");
                }

                System.arraycopy(iv, 0, IV, 0, iv.length);

                reset();

                desede.init(encrypting, ivParam.getParameters());
            }
            else
            {
                reset();

                desede.init(encrypting, params2);
            }
        }

        public int getBlockSize()
        {
            return cipher.getBlockSize();
        }

        public int processBlock(byte[] in,
                                int inOff,
                                byte[] out,
                                int outOff, boolean lastBlock)
                throws DataLengthException, IllegalStateException
        {
            return encrypting ? encryptBlock(in, inOff, out, outOff, lastBlock) : decryptBlock(in, inOff, out, outOff, lastBlock);
        }

        public void reset()
        {
            System.arraycopy(IV, 0, cbcV, 0, IV.length);

            cipher.reset();
            desede.reset();
        }

        private int encryptBlock(byte[] in,
                                 int inOff,
                                 byte[] out,
                                 int outOff, boolean lastBlock)
                throws DataLengthException, IllegalStateException
        {
            if (inOff + blockSize > in.length)
            {
                throw new DataLengthException("input buffer too short");
            }

            /*
                * XOR the cbcV and the input,
                * then encrypt the cbcV
                */
            for (int i = 0; i < blockSize; i++)
            {
                cbcV[i] ^= in[inOff + i];
            }

            int length;
            if (lastBlock)
            {
                length = desede.processBlock(cbcV, 0, out, outOff);
            }
            else
            {
                length = cipher.processBlock(cbcV, 0, out, outOff);
            }

            /*
                * copy ciphertext to cbcV
                */
            System.arraycopy(out, outOff, cbcV, 0, cbcV.length);

            return length;
        }

        private int decryptBlock(byte[] in,
                                 int inOff,
                                 byte[] out,
                                 int outOff, boolean lastBlock)
                throws DataLengthException, IllegalStateException
        {
            if (inOff + blockSize > in.length)
            {
                throw new DataLengthException("input buffer too short");
            }

            System.arraycopy(in, inOff, cbcNextV, 0, blockSize);

            int length;
            if (lastBlock)
            {
                length = desede.processBlock(in, inOff, out, outOff);
            }
            else
            {
                length = cipher.processBlock(in, inOff, out, outOff);
            }

            /*
                * XOR the cbcV and the output
                */
            for (int i = 0; i < blockSize; i++)
            {
                out[outOff + i] ^= cbcV[i];
            }

            /*
                * swap the back up buffer into next position
                */
            byte[] tmp;

            tmp = cbcV;
            cbcV = cbcNextV;
            cbcNextV = tmp;

            return length;
        }
    }
}
