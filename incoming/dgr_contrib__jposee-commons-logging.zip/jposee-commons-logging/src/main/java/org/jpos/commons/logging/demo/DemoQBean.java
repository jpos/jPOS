package org.jpos.commons.logging.demo;

import java.util.Calendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jpos.q2.QBeanSupport;

public class DemoQBean extends QBeanSupport {

	private static Log logger = LogFactory.getLog(DemoQBean.class);
	
    public void startService() {
    	logger.info(String.format("Hi there, this line is traced through the commons-logging API (%s)", Calendar.getInstance().getTime().toString()));
    }
}
